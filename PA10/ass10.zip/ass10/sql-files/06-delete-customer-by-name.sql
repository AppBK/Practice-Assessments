-- Your code here
DELETE FROM customers
WHERE customers.first_name = 'John' AND customers.last_name = 'Smith';

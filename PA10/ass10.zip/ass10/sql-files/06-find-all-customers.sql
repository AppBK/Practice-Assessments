-- Your code here
SELECT customers.first_name, customers.last_name
FROM customers ORDER BY customers.last_name, customers.first_name;

-- Your code here
SELECT departments.name FROM departments;

-- Your code here
DELETE FROM departments
WHERE departments.name = 'Plumbing';
